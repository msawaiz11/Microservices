from django.apps import AppConfig


class MainDishAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Main_Dish_App"
