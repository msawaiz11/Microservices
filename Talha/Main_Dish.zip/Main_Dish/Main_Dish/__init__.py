from __future__ import absolute_import, unicode_literals

from .celery import app as Main_Dish_App

__all__ = ('Main_Dish_App',)
