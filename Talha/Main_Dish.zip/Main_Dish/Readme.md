Run Porject by running only the file 

Python script.py 